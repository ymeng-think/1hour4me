//
//  RootViewController.m
//  MultiRowSelect
//
//  Created by Matt Gallagher on 11/01/09.
//  Copyright Matt Gallagher 2009. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "RootViewController.h"
#import "MultiRowSelectAppDelegate.h"
#import "MultiSelectCellController.h"

@implementation RootViewController

//
// dealloc
//
// Releases instance memory.
//
- (void)dealloc
{
	[actionToolbar release];
	[super dealloc];
}


//
// constructTableGroups
//
// Creates cell data.
//
- (void)constructTableGroups
{
	const NSInteger NUM_ROWS = 20;
	
	NSMutableArray *selectableRows = [NSMutableArray array];
	NSInteger i;
	for (i = 0; i < NUM_ROWS; i++)
	{
		[selectableRows addObject:
			[[[MultiSelectCellController alloc]
				initWithLabel:[NSString stringWithFormat:@"Row %ld", i]]
			autorelease]];
	}

	tableGroups = [[NSArray alloc] initWithObjects:selectableRows, nil];
}

//
// noAction:
//
// Clears the selection but otherwise does nothing.
//
- (void)noAction:(id)sender
{
	NSInteger row = 0;
	for (MultiSelectCellController *cellController in [tableGroups objectAtIndex:0])
	{
		[cellController clearSelectionForTableView:self.tableView
			indexPath:[NSIndexPath indexPathForRow:row inSection:0]];
		row++;
	}
}

//
// viewDidLoad
//
// Create the logout button
//
- (void)viewDidLoad
{
	[super viewDidLoad];
	
	actionToolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 416, 320, 44)];
	actionButton =
		[[[UIBarButtonItem alloc]
			initWithTitle:@"No Action"
			style:UIBarButtonItemStyleBordered
			target:self
			action:@selector(noAction:)]
		autorelease];
	[actionToolbar setItems:[NSArray arrayWithObject:actionButton]];
	
	[self.tableView setAllowsSelectionDuringEditing:YES];

	//
	// Set the state for not editing.
	//
	[self cancel:self];
}

//
// viewDidAppear:
//
// Add the actionToolbar when this view appears
//
- (void)viewDidAppear:(BOOL)animated
{
	[self.view.superview addSubview:actionToolbar];
}

//
// viewWillDisappear:
//
// Remove the actionToolbar when this view disappears
//
- (void)viewWillDisappear:(BOOL)animated
{
	[actionToolbar removeFromSuperview];
}

//
// edit:
//
// Toggles edit mode.
//
- (void)edit:(id)sender
{
	[self showActionToolbar:YES];
	
	UIBarButtonItem *cancelButton =
		[[[UIBarButtonItem alloc]
			initWithTitle:@"Cancel"
			style:UIBarButtonItemStyleDone
			target:self
			action:@selector(cancel:)]
		autorelease];
	[self.navigationItem setRightBarButtonItem:cancelButton animated:NO];
	[self updateSelectionCount];
	
	[self.tableView setEditing:YES animated:YES];
}

//
// cancel:
//
// Remove the editing
//
- (void)cancel:(id)sender
{
	[self showActionToolbar:NO];

	UIBarButtonItem *editButton =
		[[[UIBarButtonItem alloc]
			initWithTitle:@"Edit"
			style:UIBarButtonItemStylePlain
			target:self
			action:@selector(edit:)]
		autorelease];
	[self.navigationItem setRightBarButtonItem:editButton animated:NO];

	NSInteger row = 0;
	for (MultiSelectCellController *cellController in [tableGroups objectAtIndex:0])
	{
		[cellController clearSelectionForTableView:self.tableView
			indexPath:[NSIndexPath indexPathForRow:row inSection:0]];
		row++;
	}

	[self.tableView setEditing:NO animated:YES];
}

//
// updateSelectionCount
//
// Updates the selection count button when selection changes.
//
- (void)updateSelectionCount
{
	NSInteger count = 0;
	
	for (MultiSelectCellController *cellController in [tableGroups objectAtIndex:0])
	{
		if ([cellController selected])
		{
			count++;
		}
	}
	
	actionButton.title = [NSString stringWithFormat:@"No action (%ld)", count];
	actionButton.enabled = (count != 0);
}

//
// tableView:canEditRowAtIndexPath:
//
// Specifies editing enabled for all rows.
//
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
	return YES;
}

//
// showActionToolbar:
//
// Toggles the "action" toolbar
//
- (void)showActionToolbar:(BOOL)show
{
	CGRect toolbarFrame = actionToolbar.frame;
	CGRect tableViewFrame = self.tableView.frame;
	if (show)
	{
		toolbarFrame.origin.y = actionToolbar.superview.frame.size.height - toolbarFrame.size.height;
		tableViewFrame.size.height -= toolbarFrame.size.height;
	}
	else
	{
		toolbarFrame.origin.y = actionToolbar.superview.frame.size.height;
		tableViewFrame.size.height += toolbarFrame.size.height;
	}
	
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationBeginsFromCurrentState:YES];
		
	actionToolbar.frame = toolbarFrame;
	self.tableView.frame = tableViewFrame;
	
	[UIView commitAnimations];
}

@end

