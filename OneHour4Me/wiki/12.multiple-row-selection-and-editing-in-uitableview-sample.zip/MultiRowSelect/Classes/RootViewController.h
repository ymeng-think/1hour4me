//
//  RootViewController.h
//  MultiRowSelect
//
//  Created by Matt Gallagher on 11/01/09.
//  Copyright Matt Gallagher 2009. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "GenericTableViewController.h"

@interface RootViewController : GenericTableViewController
{
	UIToolbar *actionToolbar;
	UIBarButtonItem *actionButton;
}

- (void)edit:(id)sender;
- (void)cancel:(id)sender;
- (void)showActionToolbar:(BOOL)show;
- (void)updateSelectionCount;
- (void)noAction:(id)sender;

@end
